# -*- coding: utf-8 -*-
"""
Created on Tue Jul 16 23:24:04 2013

@author: Ionox
"""
"""
Oth,
try out the raw_input command,
Have it say raw_input("Tell me a number:" )
print out the number mulptiplied by 10, recall
that raw input takes numbers in as strings so you
probably gotta convert it using float(string)
"""
"""
In the zip that had this assignment
there should be  folder containing four works
of fiction.
First open up Hamlet, count the number of words in it
consider using the commands: open, read, and split(' ') (to split
it in to a list of words)
"""
"""
Second, generalize your command using a for loop and 
os.listdir to open all the works and print out how many words
are in each in the format "Hamlet.txt has X words"
"""
"""
Third, open the csv called 'data' in the other folder.
Data contains some data.
Multiply all the data in salaries column by thirty and resave 
it in a new csv.

Third and half, using the command zip(*) or itertools.izip(*)
resave data as rows instead of columns
"""
"""
Fourth, FINAL PROJECT!
Open 'parse tester'. Using a combination of split, open, close,
for loops, if, and every thing else I've taught you, pull out the numbers
and put them in a pretty array
"""
