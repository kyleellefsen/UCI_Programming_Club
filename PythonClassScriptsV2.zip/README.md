PythonClassScriptsV2
====================
Scripts for UCI's python programming club. I own none of the images, I am rehosting them. If you are the owner, contact me and I will gladly take them down.
